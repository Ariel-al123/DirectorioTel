public class Contacto {
    private String nombreCompleto;
    private String telefono;
    private String email;
    private String direccion;

    public Contacto(String nombreCompleto, String telefono, String email, String direccion) {
        this.nombreCompleto = nombreCompleto;
        this.telefono = telefono;
        this.email = email;
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombreCompleto +
                "\nTeléfono: " + telefono +
                "\nEmail: " + email +
                "\nDirección: " + direccion + "\n";
    }
}