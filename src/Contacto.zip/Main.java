import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Contacto> directorio = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\nMenú de directorio telefónico");
            System.out.println("1. Agregar nuevo contacto");
            System.out.println("2. Listar todos los contactos");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    agregarContacto();
                    break;
                case 2:
                    listarContactos();
                    break;
                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 3);
    }

    private static void agregarContacto() {
        System.out.println("\nAGREGAR NUEVO CONTACTO ");
        System.out.print("Nombre completo: ");
        String nombre = scanner.nextLine();

        System.out.print("Teléfono: ");
        String telefono = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Dirección: ");
        String direccion = scanner.nextLine();

        Contacto nuevoContacto = new Contacto(nombre, telefono, email, direccion);
        directorio.add(nuevoContacto);
        System.out.println("Contacto agregado exitosamente!");
    }

    private static void listarContactos() {
        if (directorio.isEmpty()) {
            System.out.println("\nNo hay contactos en el directorio.");
            return;
        }

        System.out.println("\nLISTA DE TODOS LOS CONTACTOS ");
        for (int i = 0; i < directorio.size(); i++) {
            System.out.println("Contacto #" + (i + 1));
            System.out.println(directorio.get(i));
        }
    }
}